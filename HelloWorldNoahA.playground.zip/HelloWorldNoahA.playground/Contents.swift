
var name = "Noah"
var language = "Swift"

var message1 = " Welcome to the wonderful world of "
var message2 = " \(name), Welcome to the wonderful world of \(language)!"

print(message2)
print(name, message1, language, "!")
