//Records of a game I played previously
let winScore = 10

//Initializes team scores as 0
var teamRedScore = 0
var teamBlueScore = 0

teamRedScore+=1
teamRedScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamRedScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamRedScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamBlueScore+=1
teamRedScore+=1
teamBlueScore+=1


if teamBlueScore == winScore{
    print("Blue team wins!")
}
else if teamRedScore == winScore{
    print("Red team wins!")
}
